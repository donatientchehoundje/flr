<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Chantier;
use App\Models\Livraison;
use App\Models\RentalContract;
use App\Models\Payment;
use App\Models\PartialDelivery;
use Inertia\Inertia;

class DashboardController extends Controller
{
    public function index()
    {
        $chantiersActifs = Chantier::where('status', 'en_cours')->count();
        $livraisonsAttente = Livraison::where('status', 'en_attente')->count();
        
        $caPrevu = RentalContract::where('status', '!=', 'annule')->sum('montant_total_prevu');
        $caEncaisse = Payment::where('payable_type', RentalContract::class)->sum('montant');
        
        $dettesTotal = Livraison::sum('montant_total_fournisseur');
        $dettesPayees = Payment::where('payable_type', Livraison::class)->sum('montant');
        $dettesRestantes = $dettesTotal - $dettesPayees;

        // Activités récentes (Paiements + Réceptions BL)
        $recentPayments = Payment::with('payable')->latest()->take(5)->get();
        $recentBL = PartialDelivery::with('livraison.chantier')->latest()->take(5)->get();

        return Inertia::render('Dashboard', [
            'stats' => [
                'chantiers_actifs' => $chantiersActifs,
                'livraisons_attente' => $livraisonsAttente,
                'ca_prevu' => (float)$caPrevu,
                'ca_encaisse' => (float)$caEncaisse,
                'dettes_fournisseurs' => (float)$dettesRestantes,
            ],
            'recent_payments' => $recentPayments,
            'recent_bl' => $recentBL,
        ]);
    }
}
