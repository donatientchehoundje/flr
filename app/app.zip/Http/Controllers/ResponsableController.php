<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Responsable;
use App\Models\Service;
use Inertia\Inertia;

class ResponsableController extends Controller
{
    public function index()
    {
        return Inertia::render('Responsables/Index', [
            'responsables' => Responsable::with('service')->latest()->get(),
            'services' => Service::all(),
        ]);
    }
    public function store(Request $request)
    {
        $validated = $request->validate([
            'service_id' => 'required|exists:services,id',
            'user_id' => 'nullable|exists:users,id',
            'nom' => 'required|string|max:255',
            'contact' => 'nullable|string|max:255',
            'email' => 'nullable|email',
        ]);

        Responsable::create($validated);

        return redirect()->back()->with('message', 'Responsable ajouté.');
    }

    public function update(Request $request, Responsable $responsable)
    {
        $validated = $request->validate([
            'service_id' => 'required|exists:services,id',
            'user_id' => 'nullable|exists:users,id',
            'nom' => 'required|string|max:255',
            'contact' => 'nullable|string|max:255',
            'email' => 'nullable|email',
        ]);

        $responsable->update($validated);

        return redirect()->back()->with('message', 'Responsable mis à jour.');
    }

    public function destroy(Responsable $responsable)
    {
        $responsable->delete();
        return redirect()->back()->with('message', 'Responsable supprimé.');
    }
}
