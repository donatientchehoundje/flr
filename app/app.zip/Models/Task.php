<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Task extends Model
{
    protected $fillable = ['responsable_id', 'libelle', 'description', 'date_echeance', 'priorite', 'status'];

    public function responsable(): BelongsTo
    {
        return $this->belongsTo(Responsable::class);
    }
}
